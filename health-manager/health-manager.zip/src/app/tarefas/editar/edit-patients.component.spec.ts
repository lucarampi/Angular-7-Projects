import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPatientsComponent } from './edit-patients.component';

describe('EditarTarefasComponent', () => {
  let component: EditPatientsComponent;
  let fixture: ComponentFixture<EditPatientsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditPatientsComponent ]
    })
    .compileComponents();
  });

});
