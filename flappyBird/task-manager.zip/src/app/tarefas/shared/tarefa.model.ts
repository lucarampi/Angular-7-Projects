export class Tarefa {
    constructor(
        public id?: number,
        public name?: string,
        public author?: string,
        public done?: boolean) {       
    }
}